module.exports = {
    // Define service name
    name: "notifications",

    actions: {
        // Define service action that returns the available products
        list(ctx) {
            return [
                { name: "Ayush", price: 23 },
                { name: "Ankit", price: 23 },
                { name: "Rahul", price: 22 }
            ];
        }
    }
}