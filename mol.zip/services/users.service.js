module.exports = {
    // Define service name
    name: "users",

    actions: {
        // Define service action that returns the available products
        login(ctx) {
            return [
                { name: "Ankit", price: 23 }
            ];
        },
        register(ctx) {
            return [
                { name: "Ayush", price: 23 }
            ];
        }
    }
}
